CREATE TABLE `facebookLogins` (
  `FB_id` bigint(20) NOT NULL PRIMARY KEY,
  `FB_email` varchar(256) NOT NULL
);
