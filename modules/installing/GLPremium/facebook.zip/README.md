# Gangster-Legends-V2-Facebook
Add Facebook login to GLv2
