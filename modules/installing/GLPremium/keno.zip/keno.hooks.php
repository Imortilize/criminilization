<?php

	new hook("casinoMenu", function () {
        return array(
            "url" => "?page=keno", 
            "text" => "Keno"
        );
    });