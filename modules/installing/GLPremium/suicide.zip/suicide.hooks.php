<?php

    new hook("accountMenu", function () {
        return array(
            "url" => "?page=suicide", 
            "text" => "Commit Suicide", 
            "sort" => 390
        );
    });
?>