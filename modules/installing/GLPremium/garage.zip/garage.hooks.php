<?php
    new hook("locationMenu", function () {
        return array(
            "url" => "?page=garage", 
            "text" => "Garage"
        );
    });
?>