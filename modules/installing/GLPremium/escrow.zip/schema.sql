ALTER TABLE `userStats` ADD `US_escrowStatus` INT(11);
ALTER TABLE `userStats` ADD `US_escrowWith` INT(11);
ALTER TABLE `userStats` ADD `US_escrowItems` TEXT;