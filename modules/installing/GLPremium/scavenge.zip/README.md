# scavenge
A free scavenge module for Gangster Legends V2
