<?php

    new hook("moneyMenu", function () {
        return array(
            "url" => "?page=smuggle", 
            "text" => "Smuggle"
        );
    });