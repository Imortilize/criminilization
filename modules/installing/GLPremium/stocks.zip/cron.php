<?php

	require __DIR__ . '/../../core/config.php';
	require __DIR__ . '/../../core/dbconn.php';



?>
