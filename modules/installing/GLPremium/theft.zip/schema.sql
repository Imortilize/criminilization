ALTER TABLE `theft` ADD `T_minDamage` INT(11) DEFAULT 1;
ALTER TABLE `theft` ADD `T_cooldown` INT(11) DEFAULT 180;