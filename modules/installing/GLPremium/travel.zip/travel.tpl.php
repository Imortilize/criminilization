<?php

    class travelTemplate extends template {
    
        public $locationHolder = '

            <div class="panel panel-default">
                <div class="panel-heading">Travel</div>
                <div class="panel-body">
                    {#each locations}
                        <div class="crime-holder">
                            <p>
                                <span class="action">
                                    <a href="?page=travel&action=locationInfo&location={id}">
                                        {location} 
                                    </a>
                                </span>
                                <span class="cooldown">
                                    ({cooldown})&nbsp;&nbsp;&nbsp;&nbsp;{#money cost} 
                                </span>
                                <span class="commit">
                                    <a href="?page=travel&action=fly&location={id}">Travel</a>
                                </span>
                            </p>
                            <div class="crime-img color" style="background-image: url(modules/installed/locations/images/{id}.jpg);"></div>
                        </div>
                    {/each}
                </div>
            </div>
        ';

        public $locationInfo = '
            <div class="row">
                <div class="col-md-5">
                    <div class="panel panel-default location">
                        <div class="panel-heading">
                            {name}
                        </div>
                        <img class="img-responsive" src="modules/installed/locations/images/{id}.jpg" />
                        <div class="list-group text-left">
                            <div class="list-group-item">
                                <strong>Population:</strong> 
                                <small class="pull-right">{number_format population}</small>
                            </div>
                            <div class="list-group-item">
                                <strong>{_setting "gangName"}:</strong> 
                                {#if gang}
                                    <small class="pull-right">
                                        <a href="?page=gangs&action=view&id={gang.id}">
                                            {gang.name}
                                        </a>
                                    </small>
                                {/if}
                                {#unless gang}
                                    <small class="pull-right">None</small>
                                {/unless}
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-7">
                    <div class="panel panel-default location">
                        <div class="panel-heading">
                            {name} Properties
                        </div>
                        <div class="list-group">
                            {#each properties}
                                <div class="list-group-item">
                                    <div class="row">
                                        <strong class="col-md-4 text-left">
                                            <a href="?page={module}">{name}</a>
                                        </strong>
                                        {#if user}
                                            <div class="user col-md-4">
                                                {#if closed}
                                                    Closed
                                                {/if}
                                                {#unless closed}
                                                    {>userName}
                                                {/unless}
                                            </div>
                                            <small class="col-md-4 text-right">{#money cost}</small>
                                        {/if}
                                        {#unless user}
                                            <div class="user col-md-4">
                                                {#if here}
                                                    &nbsp;
                                                    <a href="?page={module}&action=own" class="btn btn-xs btn-primary">
                                                        Buy
                                                    </a>
                                                    &nbsp;
                                                {/if}
                                                {#unless here}
                                                    {#if closed}
                                                        Closed
                                                    {/if}
                                                    {#unless closed}
                                                        No Owner
                                                    {/unless}
                                                {/unless}
                                            </div>
                                            <small class="col-md-4 text-right">{add}{#money cost}</small>
                                        {/unless}
                                    </div>
                                </div>
                            {/each}
                        </div>
                    </div>
                </div>

            </div>
        ';
        
    }

?>