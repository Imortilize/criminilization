<?php

    new hook("userInformation", function ($user) {
        global $page;
        $time = $user->getTimer("travel");
        if (($time-time()) > 0) {
            $page->addToTemplate('travel_timer', $time);
        } else {
            $page->addToTemplate('travel_timer', 0);
        }
    });

    new hook("locationMenu", function ($user) {
        if ($user) return array(
            "url" => "?page=travel", 
            "timer" => $user->getTimer("travel"),
            "text" => "Travel"
        );
    });
?>
