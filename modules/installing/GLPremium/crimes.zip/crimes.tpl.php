<?php

    function _colWidth($rewards) {
        return 12 / count($rewards);
    }

    class crimesTemplate extends template {

        public $crimeSuccess = '
            <div class="panel panel-default panel-fixed">
                <div class="panel-heading">{name}</div>
                <img class="img-responsive" src="modules/installed/crimes/images/{id}.png" />
                <div class="panel-body">

                    <p>{text}</p>

                    <div class="row">
                        {#each rewards}
                            <div class="col-md-{_colWidth ../rewards}">
                                <strong>{name}:</strong> {val}
                            </div>
                        {/each}
                    </div>
                </div>
            </div>


        ';
        public $crimeHolder = '

        <div class="panel panel-default">
            <div class="panel-heading">Crimes</div>
            <div class="panel-body">
                {#each crimes}
                    <div class="crime-holder {#if locked}locked{/if}">
                        <p>
                            <span class="action">
                            {name} 
                            </span> 

                            {#if locked}
                                Unlocked at {rank}
                            {/if}

                            {#unless locked}
                                {#unless canDo}
                                    <span class="cooldown">
                                        {#if timer}
                                            <a href="?page=timerReset&reset=crime-{id}&module=crimes">
                                                Reset timer for {number_format timer} {_setting "pointsName"}
                                            </a>
                                        {/if}
                                    </span> 
                                {/unless}
                                <span class="cooldown">
                                    <span data-timer="{time}" data-timer-type="inline"></span> 
                                </span> 
                                <span class="commit">
                                    <a href="?page=crimes&action=commit&crime={id}">
                                        Commit
                                    </a>
                                </span>
                            {/unless}
                        </p>
                        {#unless locked}
                            <div class="crime-perc">
                                <div class="perc" style="width:{percent}%;"></div>
                            </div>
                        {/unless}
                    </div>
                {/each}
                {#unless crimes}
                    <div class="text-center"><em>There are no crimes</em></div>
                {/unless}
            </div>
        </div>
        ';

        public $crimeList = '
            <table class="table table-condensed table-striped table-bordered table-responsive">
                <thead>
                    <tr>
                        <th>Crime</th>
                        <th width="120px">Cooldown</th>
                        <th width="120px">Reward</th>
                        <th width="70px">Level</th>
                        <th width="70px">EXP</th>
                        <th width="100px">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {#each crimes}
                        <tr>
                            <td>{name}</td>
                            <td>{cooldown} seconds</td>
                            <td>${money} - ${maxMoney}</td>
                            <td>{level}</td>
                            <td>{exp}</td>
                            <td>
                                [<a href="?page=admin&module=crimes&action=edit&id={id}">Edit</a>] 
                                [<a href="?page=admin&module=crimes&action=delete&id={id}">Delete</a>]
                            </td>
                        </tr>
                    {/each}
                </tbody>
            </table>
        ';

        public $crimeDelete = '
            <form method="post" action="?page=admin&module=crimes&action=delete&id={id}&commit=1">
                <div class="text-center">
                    <p> Are you sure you want to delete this crime?</p>

                    <p><em>"{name}"</em></p>

                    <button class="btn btn-danger" name="submit" type="submit" value="1">Yes delete this crime</button>
                </div>
            </form>
        
        ';
        public $crimeForm = '
            <form method="post" action="?page=admin&module=crimes&action={editType}&id={id}" enctype="multipart/form-data">

                <div class="row">
                    <div class="col-md-9">
                        <div class="form-group">
                            <label class="pull-left">Crime Name</label>
                            <input type="text" class="form-control" name="name" value="{name}">
                        </div>
                    </div> 
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="pull-left">Image <small>(Leave blank to stay the same)</small></label>
                            <input type="file" class="form-control" name="image" value="">
                        </div> 
                    </div> 
                </div> 

                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="pull-left">Min. money for successful crime</label>
                            <input type="number" class="form-control" name="money" value="{money}">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="pull-left">Max. monney for successful crime</label>
                            <input type="number" class="form-control" name="maxMoney" value="{maxMoney}">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="pull-left">Min. bullets for successful crime</label>
                            <input type="number" class="form-control" name="bullets" value="{bullets}">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="pull-left">Max. bullets for successful crime</label>
                            <input type="number" class="form-control" name="maxBullets" value="{maxBullets}">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="pull-left">Chance of success (%)</label>
                            <input type="number" class="form-control" name="chance" value="{chance}">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="pull-left">Cooldown (Seconds)</label>
                            <input type="number" class="form-control" name="cooldown" value="{cooldown}">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="pull-left">EXP Gained</label>
                            <input type="number" class="form-control" name="exp" value="{exp}">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="pull-left">Min user level to comit this crime</label>
                            <select class="form-control" name="level" data-value="{level}">
                                {#each ranks}
                                    <option value="{id}">{name}</option>
                                {/each}
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="pull-left">Max user level to comit this crime</label>
                            <select class="form-control" name="levelMax" data-value="{levelMax}">
                                {#each ranks}
                                    <option value="{id}">{name}</option>
                                {/each}
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="pull-left">Cost to reset timer ({_setting "pointsName"})</label>
                            <input type="number" class="form-control" name="resetCost" value="{resetCost}">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="pull-left">Success Text</label>
                    <input type="text" class="form-control" name="successText" value="{successText}">
                </div>

                <div class="form-group">
                    <label class="pull-left">Fail Text</label>
                    <input type="text" class="form-control" name="failText" value="{failText}">
                </div>

                <div class="text-right">
                    <button class="btn btn-default" name="submit" type="submit" value="1">Save</button>
                </div>
            </form>
        ';
    }

?>