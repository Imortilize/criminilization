ALTER TABLE `crimes` ADD COLUMN `C_successText` VARCHAR(512) DEFAULT "You successfully commited this crime!";
ALTER TABLE `crimes` ADD COLUMN `C_failText` VARCHAR(512) DEFAULT "You failed this crime";
ALTER TABLE `crimes` ADD COLUMN `C_chance` INT(11) DEFAULT 60;
ALTER TABLE `crimes` ADD COLUMN `C_levelMax` INT(11) DEFAULT 60;